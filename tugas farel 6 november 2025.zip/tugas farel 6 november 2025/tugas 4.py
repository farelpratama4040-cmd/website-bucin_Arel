
print("=== Program Hitung Rata-rata ===")

# Meminta jumlah data
n = int(input("Masukkan jumlah angka yang ingin dihitung: "))

# Membaca angka-angka dari pengguna
angka = []
for i in range(n):
    nilai = float(input(f"Masukkan angka ke-{i+1}: "))
    angka.append(nilai)

# Menghitung rata-rata
rata = sum(angka) / n

# Menampilkan hasil
print(f"\nAngka yang dimasukkan: {angka}")
print(f"Rata-rata dari angka tersebut adalah: {rata:.2f}")
