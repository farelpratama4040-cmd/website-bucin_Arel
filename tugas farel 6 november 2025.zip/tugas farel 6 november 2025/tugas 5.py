# Program Cari Nilai Minimum
# Simpan file ini sebagai: cari_nilai_minimum.py
# Jalankan di Visual Studio Code dengan menekan F5 atau klik "Run ▶"

print("=== Program Cari Nilai Minimum ===")

# Meminta jumlah data
n = int(input("Masukkan jumlah angka: "))

# Membaca angka-angka dari pengguna
angka = []
for i in range(n):
    nilai = float(input(f"Masukkan angka ke-{i+1}: "))
    angka.append(nilai)

# Mencari nilai minimum
nilai_minimum = min(angka)

# Menampilkan hasil
print(f"\nAngka yang dimasukkan: {angka}")
print(f"Nilai terkecil adalah: {nilai_minimum}")
